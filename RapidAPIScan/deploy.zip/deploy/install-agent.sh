#!/usr/bin/env bash
# Install the RapidPulse agent on a Linux EC2 as a systemd service (collects Docker containers too).
#   sudo ./install-agent.sh http://10.20.0.50:4400 app my-application [ingest-key] \
#        "Orders API health=http://localhost:8080/health@orders-api" ...
set -euo pipefail
SERVER="${1:?server url}"; ROLE="${2:-}"; APP="${3:-}"; KEY="${4:-}"; shift $(( $# < 4 ? $# : 4 ))
DIR=/opt/pulse-agent
mkdir -p "$DIR"
cp "$(dirname "$0")/../agent/pulse_agent.py" "$DIR/"
python3 -m venv "$DIR/venv"
"$DIR/venv/bin/pip" install --quiet psutil==6.1.0
ARGS="--server $SERVER"
[ -n "$ROLE" ] && ARGS="$ARGS --role $ROLE"
[ -n "$APP" ] && ARGS="$ARGS --app $APP"
[ -n "$KEY" ] && ARGS="$ARGS --key $KEY"
for c in "$@"; do ARGS="$ARGS --check '$c'"; done
cat > /etc/systemd/system/pulse-agent.service <<EOF
[Unit]
Description=RapidPulse infrastructure agent
After=network-online.target docker.service

[Service]
ExecStart=/bin/sh -c "exec $DIR/venv/bin/python $DIR/pulse_agent.py $ARGS"
Restart=always
RestartSec=10
# needs the docker CLI + socket for container metrics
SupplementaryGroups=docker

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now pulse-agent
echo "pulse-agent running: systemctl status pulse-agent"
