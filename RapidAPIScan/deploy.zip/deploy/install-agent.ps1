# Install the RapidPulse agent on a Windows Server (EC2) as a self-restarting startup task running as SYSTEM.
#   .\install-agent.ps1 -Server http://10.20.0.50:4400 -Role web -App my-application `
#       -Checks "Web login=https://localhost/login@storefront" [-Key <ingest key>] [-Mssql "<odbc conn str>"]
param(
  [Parameter(Mandatory)] [string]$Server,
  [string]$Role = "", [string]$App = "", [string]$Key = "",
  [string[]]$Checks = @(), [string]$Mssql = "",
  [string]$InstallDir = "C:\Program Files\RapidPulseAgent",
  [string]$Python = "python"
)
$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force $InstallDir | Out-Null
Copy-Item "$PSScriptRoot\..\agent\pulse_agent.py" $InstallDir -Force
& $Python -m venv "$InstallDir\venv"
& "$InstallDir\venv\Scripts\python.exe" -m pip install --quiet psutil==6.1.0
if ($Mssql) { & "$InstallDir\venv\Scripts\python.exe" -m pip install --quiet pyodbc==5.2.0 }

$argList = @("`"$InstallDir\pulse_agent.py`"", "--server", $Server)
if ($Role) { $argList += @("--role", $Role) }
if ($App) { $argList += @("--app", $App) }
if ($Key) { $argList += @("--key", $Key) }
if ($Mssql) { $argList += @("--mssql", "`"$Mssql`"") }
foreach ($c in $Checks) { $argList += @("--check", "`"$c`"") }

$action = New-ScheduledTaskAction -Execute "$InstallDir\venv\Scripts\pythonw.exe" -Argument ($argList -join " ") -WorkingDirectory $InstallDir
$trigger = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName "RapidPulseAgent" -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
Start-ScheduledTask -TaskName "RapidPulseAgent"
Write-Host "RapidPulse agent installed and started (scheduled task 'RapidPulseAgent'). Check the Infrastructure page in ~15s."
